rm(list = ls())
install.packages("SentimentAnalysis")
install.packages("rtweet")
install.packages("tidyverse")
install.packages("tm")
install.packages("twitteR")
library(SentimentAnalysis)
library(rtweet)
library(tidyverse)
devtools::install_github("mkearney/rtweet")
library(twitteR)
library(tm)
auth_setup_default()
auth <- rtweet_bot() # Authenticating method

df <- search_tweets("#Chatgpt", token = auth, n = 60, include_rts = FALSE, lang = "en")

while (TRUE){
  df <- search_tweets("#Chatgpt", token = auth, n = 60, include_rts = FALSE, lang = "en",since_id = df)
  head(df$created_at)
  tweets_excel <- df
  #setwd("C:/Users/govardhan reddy/Desktop/utt second sem/Business Intelligence and analysis/BI-proj-main/BI-proj-main/BI-proj-main/BI-proj-main")
  #tweets_excel <- read.csv("test_data20.csv")
  #tweets_excel[tweets_excel= "#ChatGPT"] <- gsub("#ChatGPT", "ChatGPT", tweets_excel)
  remove_chatgpt <- function(y) gsub("#ChatGPT", "ChatGPT", y)
  tweets_excel$full_text <- remove_chatgpt(tweets_excel$full_text)
  removelink <- function(x) gsub(" ?(f|ht)(tp)(s?)(://)(.)[.|/](.)[a-z]", "", x)
  tweets_excel$full_text <- removelink(tweets_excel$full_text)
  removeHash <- function(x) clean_text <- gsub("#\\S+", "", x)
  tweets_excel$full_text <- removeHash(tweets_excel$full_text)
  removeEmoticons <- function(x) gsub("[^\x01-\x7F]", "", x)
  tweets_excel$full_text <- removeEmoticons(tweets_excel$full_text)
  documents<- tweets_excel$full_text
  sentiment <- analyzeSentiment(documents)
  sentiment$SentimentQDAP
  result<-convertToDirection(sentiment$SentimentQDAP)
  write.csv(result,"C:/Users/emera/Documents\\r_to_tab.csv",row.names=FALSE)
  df2 <- read.csv("r_to_tab.csv")
  colnames(df2)[1] <- "Model1"
  df2$Model2 <- read.csv(".csv")
  Sys.sleep(86400)
}